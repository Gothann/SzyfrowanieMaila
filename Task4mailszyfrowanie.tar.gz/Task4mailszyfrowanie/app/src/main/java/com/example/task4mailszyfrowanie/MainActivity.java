package com.example.task4mailszyfrowanie;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText input;
    Button button;
    TextView output;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        input = findViewById(R.id.inputemail);
        button = findViewById(R.id.button);
        output = findViewById(R.id.outputemail);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
           public void onClick(View v) {
               String text= String.valueOf(input.getText());
                    String doAt = text.substring(0,text.indexOf("@"));
                    String poAt=text.substring(text.indexOf("@"));
                    StringBuilder toReturn = new StringBuilder();
                    for (int i=0; i< doAt.length();i++){
                        if (i+1>doAt.length()/2){
                        toReturn.append("*");
                        }
                        else {
                           toReturn.append(doAt.toCharArray()[1]);
                        }
                    }
                    toReturn.append(poAt);
                    output.setText(toReturn.toString());
                output.setAlpha(1);

            }
        });

    }
}